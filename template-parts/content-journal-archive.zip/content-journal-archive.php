<?php
/**
 * Template part for displaying the archive page for journals.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package allard
 */ 

?>

<?php

   //the Args   https://codex.wordpress.org/Class_Reference/WP_Query#Parameters
    $args = array(
    'post_type' => 'journal',
    'posts_per_page' => -1,//show all posts and on one page
    'orderby' =>  array( 'meta_value_num' => 'DESC', 'title' => 'ASC' ),
    'meta_key' => 'allard_volume'
    
);   
  
    // The Query Results object
    $query_results_journals = new WP_Query( $args );

    //Create a counting variable to help control the loop
    $q_counter = 0;


?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <?php echo __FILE__ ?>

	<header class="entry-header">
		THE HEADER
	</header><!-- .entry-header -->

	<div class="entry-content">
    <?php
    // The Loop
    if ( $query_results_journals->have_posts() ) {
      echo '<div class="all-journal-archives">';
			echo "this query has this many posts: " . $query_results_journals->post_count ;
	while ( $query_results_journals->have_posts() ) {
        //set up some variables
		
		if($q_counter==0){
			$query_results_journals->the_post();  //iterate the post variable forward
		}
		$q_counter+=1;
		
    $volume_number=get_post_meta( get_the_ID(), 'allard_volume', true );
    $issues = ""; 
        
        //build the divs based on volume_number while the volume number is the same.
        while( $volume_number==get_post_meta( get_the_ID(), 'allard_volume', true ) ){       
            $issues .=  '<li> <a href="' . get_the_permalink() .'" title="'. '">'. get_the_title() .  '</a></li>';      
            $query_results_journals->the_post();  //iterate the post variable forward 
        }//endwhile for  divs based on volume_number
        ?>
        
        <div class="a-journal-archive">
                 <div class="big-volume-number">
                    Volume 
                     <?php echo $volume_number; ?>
                 </div>
                 <div class="volume-issues">
                     <ul>
                        <?php echo $issues; ?>
                     </ul>    
                </div>
        </div>
        
<?php        
	}//end while have posts
    
	echo '</div>';//.all-journal-archives

} else {
	echo 'The Archive for Jounral Volumes is currently empty. ';//what to say when if have posts is false.
}
  
  /* Restore original Post Data */
  wp_reset_postdata();

	?>

	</div><!-- .entry-content -->

	<footer class="entry-footer">
		<?php allard_entry_footer(); ?>
	</footer><!-- .entry-footer -->
</article><!-- #post-## -->
